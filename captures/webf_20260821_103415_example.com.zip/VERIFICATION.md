# Evidence Package Verification

## Manifest Integrity

SHA-256: `8bb3480dcf009304dfbaf425d989cc5b4a06d5aec4ddcf98daf9f2bc928a92de`
SHA-512: `0cd5d21fb732a38ed5078cf0a3fccda4bb09cf9540d45e815c763a7024f6bc46be68a115f6fd35ff3e35c4211d3b0652a572c09c8f5dd7af7f64aacddeb375e1`

Recompute with:
```
# Linux/macOS
sha256sum manifest.json
# Windows PowerShell
Get-FileHash manifest.json -Algorithm SHA256
```

## RFC 3161 Timestamp Verification

Run `timestamp/verify.sh` (Linux/macOS) or `timestamp/verify.ps1` (Windows).
OpenSSL >= 1.1.0 must be available in PATH.

## Individual Artifact Hashes

| File | SHA-256 |
|------|---------|
| `capture/http_response_raw.bin` | `81d5c86689374b50254773797075803efc84d909eb9d0c1c42526f6d7972608c` |
| `capture/page.warc.gz` | `2a160cc7b79f55f9f940d5e2d379261594c9140d0ec51369bbb3374f9950b8f4` |

These hashes can be independently verified against the files inside this ZIP to confirm no tampering has occurred.