# Evidence Package Verification

## Manifest Integrity

SHA-256: `e4e7206a9d530d60d22583ecc1cfe4f9cbdb7834d64c8f42a2e22bd37bba156d`
SHA-512: `523cea45a20ebfb7189c0dfa8484ae92e5fc9e820b44c1191f76140fbe148ac7ba0ea24c17feb1949e48067c28eccd9827e32f4def65bb3480b14f5266eaee21`

Recompute with:
```
# Linux/macOS
sha256sum manifest.json
# Windows PowerShell
Get-FileHash manifest.json -Algorithm SHA256
```

## RFC 3161 Timestamp Verification

Run `timestamp/verify.sh` (Linux/macOS) or `timestamp/verify.ps1` (Windows).
OpenSSL >= 1.1.0 must be available in PATH.

## Individual Artifact Hashes

| File | SHA-256 |
|------|---------|
| `capture/http_response_raw.bin` | `787f7dc3e43b55bfdf79760729e698518cfe94766278f2e4e2993ec12a052b1b` |
| `capture/page.warc.gz` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |

These hashes can be independently verified against the files inside this ZIP to confirm no tampering has occurred.