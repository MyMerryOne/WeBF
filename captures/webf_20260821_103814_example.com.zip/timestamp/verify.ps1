# RFC 3161 timestamp verification (PowerShell / Windows)
# Requires: OpenSSL available in PATH (e.g. from Git for Windows)
# Usage: pwsh verify.ps1

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host "=== Verifying RFC 3161 timestamp token ==="
Write-Host "TSA: https://freetsa.org/tsr"
Write-Host ""

$tsqPath = Join-Path $ScriptDir "request.tsq"
$tsrPath = Join-Path $ScriptDir "response.tsr"
$caPath  = Join-Path $ScriptDir "tsa_ca.pem"

if (-not (Test-Path $caPath)) {
    Write-Host "Extracting TSA certificate from response..."
    & openssl ts -reply -in $tsrPath -text 2>$null |
        Select-String -Pattern "Certificate:" -Context 0,100 |
        Out-String |
        & openssl x509 -inform PEM -out $caPath 2>$null
}

& openssl ts -verify -queryfile $tsqPath -in $tsrPath -CAfile $caPath
if ($LASTEXITCODE -eq 0) {
    Write-Host "RESULT: Timestamp VERIFIED" -ForegroundColor Green
} else {
    Write-Host "RESULT: Timestamp VERIFICATION FAILED" -ForegroundColor Red
}

Write-Host ""
Write-Host "=== Timestamp details ==="
& openssl ts -reply -in $tsrPath -text 2>$null |
    Select-String -Pattern "Status|Time stamp|TSA:|Serial Number"
