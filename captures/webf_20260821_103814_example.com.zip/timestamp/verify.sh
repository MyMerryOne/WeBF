#!/usr/bin/env bash
# RFC 3161 timestamp verification
# Requires: OpenSSL >= 1.1.0
# Usage: bash verify.sh

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=== Verifying RFC 3161 timestamp token ==="
echo "TSA: https://freetsa.org/tsr"
echo ""

# Download the TSA CA certificate bundle if not present
if [ ! -f "$SCRIPT_DIR/tsa_ca.pem" ]; then
  echo "Fetching TSA certificate chain from response..."
  openssl ts -reply -in "$SCRIPT_DIR/response.tsr" -text 2>/dev/null | \
    grep -A 100 "TSA Certificate:" | \
    openssl x509 -inform PEM > "$SCRIPT_DIR/tsa_ca.pem" 2>/dev/null || true
fi

openssl ts -verify \
  -queryfile "$SCRIPT_DIR/request.tsq" \
  -in "$SCRIPT_DIR/response.tsr" \
  -CAfile "$SCRIPT_DIR/tsa_ca.pem" \
  && echo "RESULT: Timestamp VERIFIED — token is authentic and has not been tampered with." \
  || echo "RESULT: Timestamp VERIFICATION FAILED."

echo ""
echo "=== Timestamp details ==="
openssl ts -reply -in "$SCRIPT_DIR/response.tsr" -text 2>/dev/null | \
  grep -E "(Status|Time stamp|TSA:|Serial Number)"
