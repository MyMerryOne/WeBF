# Evidence Package Verification

## Manifest Integrity

SHA-256: `b048c7b5127baa09d65b4e2e9d9565cfc331654925771e0ec7ff6a68e7af5e26`
SHA-512: `8acccf8d804c98e7585c40ccab8f139d15d6c49e76a1cb8abdf265b7f8e8a7bdb91668dd423467bc10b2a9e1702f253ddc73e25ee40982be52e3dd6348a5a35f`

Recompute with:
```
# Linux/macOS
sha256sum manifest.json
# Windows PowerShell
Get-FileHash manifest.json -Algorithm SHA256
```

## RFC 3161 Timestamp Verification

Run `timestamp/verify.sh` (Linux/macOS) or `timestamp/verify.ps1` (Windows).
OpenSSL >= 1.1.0 must be available in PATH.

## Individual Artifact Hashes

| File | SHA-256 |
|------|---------|
| `capture/http_response_raw.bin` | `5a7fb3577ead9cab34d5ca0c658eb484de9d5ac28dcc09d86abf53515280b232` |
| `capture/page.warc.gz` | `3f70307261278d7fd05f27a85590fe4c031b8de7177fcff31d3cbe6500027950` |

These hashes can be independently verified against the files inside this ZIP to confirm no tampering has occurred.